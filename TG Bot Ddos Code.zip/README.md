## Contact 

For any queries or support or removal, contact @MrJasonGod(https://t.me/MrJasonGod) on Telegram. 


--_----_----_----_----_----_----_----_----_----_----_----_----_----_----_----



   pip install telebot
   pip install flask
   pip install aiogram
   chmod +x *
   python mg.py

